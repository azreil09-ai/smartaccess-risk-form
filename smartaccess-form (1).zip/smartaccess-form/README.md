# SmartAccess — טופס ניהול סיכונים

## העלאה ל-Netlify (5 דקות)

### שלב 1 — הורד את התיקייה
הורד את תיקיית `smartaccess-form` כולה.

### שלב 2 — Netlify
1. כנס ל- https://app.netlify.com
2. לחץ **"Add new site"** ← **"Deploy manually"**
3. **גרור את כל תיקיית `smartaccess-form`** לתוך הדף
4. חכה ~2 דקות לבניה
5. קבל קישור כמו `amazing-form-123.netlify.app`

### שלב 3 — בדוק
פתח את הקישור, מלא טופס, לחץ "הורד PDF" — אמור להגיע PDF מלא.

## מבנה הפרויקט
```
smartaccess-form/
├── netlify.toml              # הגדרות Netlify
├── public/
│   └── index.html            # הטופס
└── netlify/functions/
    ├── package.json          # jsPDF dependency
    └── generate-pdf.js       # הפונקציה שיוצרת PDF
```

## שינוי כתובת האתר
ב-Netlify: Site settings → Domain management → Custom domain
